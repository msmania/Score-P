var searchData=
[
  ['name',['name',['../structSCOREP__Metric__Plugin__MetricProperties.html#ace618c2d2a50f423b963e5615ed6c502',1,'SCOREP_Metric_Plugin_MetricProperties::name()'],['../structSCOREP__Metric__Properties.html#a2b2b1c12e1ed5db0cdd2cb39ddd5a103',1,'SCOREP_Metric_Properties::name()']]],
  ['new_5fdefinition_5fhandle',['new_definition_handle',['../structSCOREP__SubstratePluginInfo.html#a0332f4c06383af4d1c34d4ee9b44f3ac',1,'SCOREP_SubstratePluginInfo']]]
];
