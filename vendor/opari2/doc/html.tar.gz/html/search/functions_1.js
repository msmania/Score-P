var searchData=
[
  ['freepomp2regioninfomembers',['freePOMP2RegionInfoMembers',['../pomp2__region__info_8h.html#a328c8dd30c3edae6a9c076f990ea36c6',1,'pomp2_region_info.h']]],
  ['freepomp2userregioninfomembers',['freePOMP2UserRegionInfoMembers',['../pomp2__user__region__info_8h.html#af2baca6fe4127338e932a68d84af374f',1,'pomp2_user_region_info.h']]]
];
